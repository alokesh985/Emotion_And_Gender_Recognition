#Import required modules
from __future__ import division
#from keras.models import Sequential
#from keras.layers import Dense
from keras.models import load_model
import numpy as np
#import os


#Load Model
model = load_model("emotion_trained_model.hdf5")

#Predictions on test data
true_list = []
pred_list = []

test_x = np.load("xtest.npy")
test_y = np.load("ytest.npy")

pred = model.predict(test_x)
pred1 = pred.tolist()
pred2 = test_y.tolist()
count = 0

for i in range(len(test_y)):
    max_value1 = max(pred1[i])
    max_value2 = max(pred2[i])
    pred_list.append(pred1[i].index(max_value1))
    true_list.append(pred2[i].index(max_value2))
    if(pred1[i].index(max_value1) == pred2[i].index(max_value2)):
        count += 1
        
accuracy = (count / len(test_y)) * 100

print("Accuracy on test set : "+str(accuracy)+"%")