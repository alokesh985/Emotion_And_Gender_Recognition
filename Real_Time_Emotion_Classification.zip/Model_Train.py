import sys,os
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from keras.models import Sequential
from keras.layers import Dense,Dropout,Activation,Flatten
from keras.layers import Conv2D,MaxPooling2D,BatchNormalization
from keras.losses import categorical_crossentropy
from keras.optimizers import Adam
from keras.regularizers import l2

#We have 7 emotions, so number of labels is 7
#Batch Size is set as 64
#Number of epochs = 100
#Size of the image is 48*48
features = 64
labels = 7
batch_size = 64
epochs = 100
width,height = 48,48

#Features are loaded into variable, x and labels are loaded into variable, y
x = np.load("fdataX.npy")
y = np.load("flabels.npy")

#Features are standardized. (Brought into same scale)
x -= np.mean(x, axis = 0)
x /= np.std(x, axis = 0)

#train_test_split() splits the dataset into training, testing and validation datasets
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.1, random_state = 42)
x_train, x_valid, y_train, y_valid = train_test_split(x_train, y_train, test_size = 0.1, random_state = 41)

#saving the test samples to be used later
np.save("xtest",x_test)
np.save("ytest",y_test)


#THE MODEL
#Designing The Model
model = Sequential()

model.add(Conv2D(features, kernel_size=(3,3),activation='relu',input_shape=(width,height,1),data_format='channels_last',kernel_regularizer=l2(0.1)))
model.add(Conv2D(features, kernel_size=(3,3), activation='relu', padding='same'))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2,2),strides=(2,2)))
model.add(Dropout(0.5))

model.add(Conv2D(2*features, kernel_size=(3, 3), activation='relu', padding='same'))
model.add(BatchNormalization())
model.add(Conv2D(2*features, kernel_size=(3, 3), activation='relu', padding='same'))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2), strides=(2, 2)))
model.add(Dropout(0.5))

model.add(Conv2D(2*2*features, kernel_size=(3, 3), activation='relu', padding='same'))
model.add(BatchNormalization())
model.add(Conv2D(2*2*features, kernel_size=(3, 3), activation='relu', padding='same'))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2), strides=(2, 2)))
model.add(Dropout(0.5))

model.add(Conv2D(2*2*2*features, kernel_size=(3, 3), activation='relu', padding='same'))
model.add(BatchNormalization())
model.add(Conv2D(2*2*2*features, kernel_size=(3, 3), activation='relu', padding='same'))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2), strides=(2, 2)))
model.add(Dropout(0.5))

model.add(Flatten())

model.add(Dense(2*2*2*features, activation='relu'))
model.add(Dropout(0.4))
model.add(Dense(2*2*features, activation='relu'))
model.add(Dropout(0.4))
model.add(Dense(2*features, activation='relu'))
model.add(Dropout(0.5))

model.add(Dense(labels, activation='softmax'))

#Compiling the model with Adam optimizer
model.compile(loss = categorical_crossentropy, optimizer = Adam(lr = 0.001, beta_1 = 0.9, beta_2 = 0.999, epsilon = 1e-7), metrics = ['accuracy'])


#Training the model
model.fit(np.array(x_train), np.array(y_train), batch_size = batch_size, epochs = epochs, verbose = 1, validation_data = (np.array(x_valid),np.array(y_valid)), shuffle = True)

#Saving the trained model
trained_model = model.to_json()
with open("model.json","w") as json_file:
    json_file.write(trained_model)
model.save_weights("trained_model.h5")
print("Model Saved!")







