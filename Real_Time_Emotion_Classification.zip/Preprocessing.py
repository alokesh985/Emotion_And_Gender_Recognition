import pandas as pd
import numpy as np
import warnings

#Warnings are ignored
warnings.filterwarnings("ignore")

df = pd.read_csv("fer2013.csv",nrows=5000)

#Image size is 48*48
width , height = 48,48

#tolist() converts series to list
datapoints = df["pixels"].tolist()

#asarray() converts any given input into an array
#reshape() changes an array without changing the data of the array
#astype() is used to cast a pandas object to a specific data type    
features = []
for x in datapoints:
    a = [int(q) for q in x.split(' ')]
    a = np.asarray(a).reshape(width,height)
    features.append(a.astype('float'))

#expand_dims expands the array by inserting a new axis at the specified position    
features = np.asarray(features)
features = np.expand_dims(features,-1)

#Getting Labels for training
#get_dummies converts categorical variable to dummy/indicator variables.
labels = pd.get_dummies(df['emotion'].as_matrix())

#Stroing labels and data
np.save("fdataX",features)
np.save("flabels",labels)

print("Preprocessing Done!")
print("Number of Data Items : "+str(len(features[0])))
print("Number of Labels : "+str(len(labels[0])))
print("Number of examples in dataset : "+str(len(features)))
print("Features, Labels stored in fdataX.npy and flabels.npy respectively!")


    


